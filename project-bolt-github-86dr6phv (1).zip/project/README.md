# Planmoni

A React Native Expo app for financial planning and monitoring.
